from datetime import datetime, timedelta

from aiogram import F, Router
from aiogram.types import CallbackQuery

from database import async_session_maker
from keyboards.keyboards import liked_me_actions_kb, main_menu_kb
from services.like_service import (
    delete_pending_like, get_pending_likes_for_user, record_like,
)
from services.user_service import can_like, get_user, increment_likes_today
from utils.logger import logger

router = Router()

PENDING_EXPIRE_HOURS = 3


@router.callback_query(F.data == "who_liked_me")
async def who_liked_me(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id

    async with async_session_maker() as session:
        pending_list = await get_pending_likes_for_user(session, user_id)

    if not pending_list:
        await callback.message.answer(
            "💔 Пока никто не лайкнул вашу анкету. Попробуйте поискать сами!",
            reply_markup=main_menu_kb(),
        )
        return

    active = [(pl, exp) for pl, exp in pending_list if not exp]
    expired = [(pl, exp) for pl, exp in pending_list if exp]

    await callback.message.answer(
        f"❤️ <b>Кто меня лайкнул</b>\n\n"
        f"Активные: {len(active)} | Просроченные: {len(expired)}",
        parse_mode="HTML",
    )

    async with async_session_maker() as session:
        for pl, is_expired in pending_list:
            liker = await get_user(session, pl.user_id)
            if not liker:
                continue
            photos = liker.photo_ids or []
            text = (
                f"{'⏰ <i>Просрочено</i>\n' if is_expired else ''}"
                f"👤 <b>{liker.first_name}</b>, {liker.age} лет\n"
                f"🏙️ {liker.city}\n"
                f"📝 {liker.description}"
            )
            kb = liked_me_actions_kb(pl.user_id, is_expired)
            if photos:
                await callback.message.answer_photo(photos[0], caption=text, parse_mode="HTML", reply_markup=kb)
            else:
                await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("like_back_"))
async def like_back(callback: CallbackQuery):
    liker_id = int(callback.data.split("_")[2])
    user_id = callback.from_user.id

    async with async_session_maker() as session:
        user = await get_user(session, user_id)
        if not user:
            await callback.answer("Профиль не найден.", show_alert=True)
            return

        pending_list = await get_pending_likes_for_user(session, user_id)
        pending_map = {pl.user_id: (pl, exp) for pl, exp in pending_list}

        if liker_id not in pending_map:
            await callback.answer("Лайк не найден.", show_alert=True)
            return

        _, is_expired = pending_map[liker_id]
        if is_expired:
            await callback.answer(
                "⏰ Эта анкета уже неактуальна. Пользователь проявил интерес более 3 часов назад, но вы не ответили.",
                show_alert=True,
            )
            return

        if not await can_like(session, user):
            await callback.answer(
                "⚠️ Вы исчерпали дневной лимит (30 лайков). Оформите LovaPlus для безлимита!",
                show_alert=True,
            )
            return

        from services.user_service import is_lovaplus_active
        is_lovaplus_like = is_lovaplus_active(user)
        is_match, already = await record_like(session, user_id, liker_id, is_lovaplus_like)
        if not already:
            await increment_likes_today(session, user_id)

        liker = await get_user(session, liker_id)
        liker_username = f"@{liker.username}" if liker and liker.username else f"#{liker_id}"
        user_username = f"@{user.username}" if user.username else f"#{user_id}"

    if is_match:
        from keyboards.keyboards import report_in_match_kb
        match_text = (
            f"🎉 <b>Взаимная симпатия!</b>\n\nВы можете пообщаться с {liker_username}\n\n"
            "⚠️ Не переводите деньги, не делитесь личными данными."
        )
        match_for_liker = (
            f"🎉 <b>Взаимная симпатия!</b>\n\nВы можете пообщаться с {user_username}\n\n"
            "⚠️ Не переводите деньги, не делитесь личными данными."
        )
        await callback.message.answer(match_text, parse_mode="HTML", reply_markup=report_in_match_kb(liker_id))
        try:
            await callback.bot.send_message(liker_id, match_for_liker, parse_mode="HTML", reply_markup=report_in_match_kb(user_id))
        except Exception as e:
            logger.warning(f"Match notification failed for {liker_id}: {e}")
        await callback.answer("🎉 Мэтч!")
    else:
        await callback.answer("❤️ Лайк отправлен!")


@router.callback_query(F.data.startswith("skip_pending_"))
async def skip_pending(callback: CallbackQuery):
    liker_id = int(callback.data.split("_")[2])
    async with async_session_maker() as session:
        await delete_pending_like(session, liker_id, callback.from_user.id)
    await callback.answer("Пропущено.")
    await callback.message.delete()


@router.callback_query(F.data.startswith("delete_pending_"))
async def delete_pending(callback: CallbackQuery):
    liker_id = int(callback.data.split("_")[2])
    async with async_session_maker() as session:
        await delete_pending_like(session, liker_id, callback.from_user.id)
    await callback.answer("Удалено.")
    await callback.message.delete()
